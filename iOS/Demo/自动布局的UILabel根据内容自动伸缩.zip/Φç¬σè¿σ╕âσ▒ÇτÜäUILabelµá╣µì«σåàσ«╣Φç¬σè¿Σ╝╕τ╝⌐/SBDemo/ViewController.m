//
//  ViewController.m
//  SBDemo
//
//  Created by liangyk on 15/8/23.
//  Copyright (c) 2015年 liangyk. All rights reserved.
//

#import "ViewController.h"
#import "OneTableViewCell.h"


@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *oneTableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.oneTableView.delegate = self;
    self.oneTableView.dataSource = self;
    
    //[self.oneTableView registerClass:[OneTableViewCell class] forCellReuseIdentifier:@"OneTableViewCell"];
    
    //[self.oneTableView registerNib:[UINib nibWithNibName:@"OneTableViewCell" bundle:nil] forCellReuseIdentifier:@"OneTableViewCell"];
    
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 100;
}


-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OneTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"OneTableViewCell"forIndexPath:indexPath];

    NSString * xxx = @"我的名字不定长度";
    cell.nameLabel.text = [xxx substringToIndex:arc4random()%9];
    
    NSArray * yyy = @[@"男人",
                      @"外星人",
                      @"未知生物",
                      @"半男+半女"];
    cell.sexLabel.text = yyy[arc4random()%4];
    return cell;
}


@end
