//
//  OneTableViewCell.m
//  SBDemo
//
//  Created by liangyk on 15/8/23.
//  Copyright (c) 2015年 liangyk. All rights reserved.
//

#import "OneTableViewCell.h"

@implementation OneTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
