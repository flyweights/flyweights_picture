//
//  OneTableViewCell.h
//  SBDemo
//
//  Created by liangyk on 15/8/23.
//  Copyright (c) 2015年 liangyk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *sexLabel;

@end
