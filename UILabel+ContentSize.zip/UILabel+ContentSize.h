#import <UIKit/UIKit.h>
 
@interface UILabel (ContentSize)
 
- (CGSize)contentSize;
 
@end